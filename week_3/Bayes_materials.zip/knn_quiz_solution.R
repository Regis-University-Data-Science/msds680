# use the iris dataset to create train and test sets
# find the best k for KNN by trying k from 1 through 20 on the train set
# plot k vs accuracy
# make a confusion matrix of the results on the test set
# write at least 1 sentence explaining/interpreting the confusion matrix
set.seed(42)  # set the random seed for reproducibility
str(iris)

# create the train indices with createDataPartition
library(caret)
train.indices <- createDataPartition(iris$Species, p = 0.8)$Resample1
library(data.table)
iris.dt <- as.data.table(iris)
train <- iris.dt[train.indices, ]
test <- iris.dt[-train.indices]

trControl <- trainControl(method  = "repeatedcv",
                          number  = 3,
                          repeats = 30)

fit <- train(Species ~ .,
             method     = 'knn',
             tuneGrid   = expand.grid(k = 1:20),
             trControl  = trControl,
             preProcess = c("center", "scale"),
             metric     = "Accuracy",
             data       = train)

print(fit)
plot(fit$results$k, fit$results$Accuracy)

# 7 or 8 for k seems to be best
preds <- predict(fit, test)
confusionMatrix(preds, test$Species)
