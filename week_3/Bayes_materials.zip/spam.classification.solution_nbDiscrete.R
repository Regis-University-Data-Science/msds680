library(data.table)
library(caret)
set.seed(42)

filename <- '~/Dropbox/MSDS/MSDS680_ncg_S8W1_18/week3/dtm.dense.csv'
dtm.dt <- fread(filename)
# save doc names and delete them from data.table
doc.names <- dtm.dt$V1
dtm.dt[, V1:=NULL]
filename <- '~/Dropbox/MSDS/MSDS680_ncg_S8W1_18/week3/spam.labels.csv'
labels <- fread(filename)
dim(labels)
labels[, V1:=as.factor(V1)]
names(labels) <- 'label'
str(labels)
dtm.dt[, label:=labels$label]
dim(dtm.dt)

train.idxs <- createDataPartition(1:dim(dtm.dt)[1], p = 0.8)$Resample1
train <- dtm.dt[train.idxs]
test <- dtm.dt[-train.idxs]
dim(train)


# enable parallel processing with all except for one of our CPU cores
library(parallel)
library(doMC)
registerDoMC(cores = detectCores() - 1)

start <- as.numeric(as.POSIXct(Sys.time()))
model <- train(label ~ .,
               data = train,
               method = 'nbDiscrete',
               metric = "Accuracy")
end <- as.numeric(as.POSIXct(Sys.time()))
print(paste(c('took', end-start, 'seconds'), sep = ' '))

model

start <- as.numeric(as.POSIXct(Sys.time()))
train.preds <- predict(model, train)
test.preds <- predict(model, test)
postResample(train.preds, train$label)
postResample(test.preds, test$label)
end <- as.numeric(as.POSIXct(Sys.time()))
print(paste(c('took', end-start, 'seconds'), sep = ' '))

confusionMatrix(test.preds, test$label)
