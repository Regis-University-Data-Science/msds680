library(data.table)
library(caret)
set.seed(42)

filename <- '~/Dropbox/MSDS/MSDS680_ncg_S8W1_18/week3/dtm.dense.csv'
dtm.dt <- fread(filename)
# save doc names and delete them from data.table
doc.names <- dtm.dt$V1
dtm.dt[, V1:=NULL]
filename <- '~/Dropbox/MSDS/MSDS680_ncg_S8W1_18/week3/spam.labels.csv'
labels <- fread(filename)
dim(labels)
labels[, V1:=as.factor(V1)]
names(labels) <- 'label'
str(labels)
dtm.dt[, label:=labels$label]
dtm.dt <- dtm.dt[][][sample(.N, 1000)]
dim(dtm.dt)

train.idxs <- createDataPartition(1:dim(dtm.dt)[1], p = 0.8)$Resample1
train <- dtm.dt[train.idxs]
test <- dtm.dt[-train.idxs]
dim(train)

trControl <- trainControl(method = 'cv', number = 3)

# enable parallel processing with all except for one of our CPU cores
library(parallel)
library(doMC)
registerDoMC(cores = detectCores() - 1)

train.feats <- train[, -'label']
model <- train(x = as.matrix(train.feats),
               y = train$label,
               method = 'naive_bayes',
               metric = "Accuracy",
               tuneGrid = expand.grid(fL = 1, usekernel = c(T, F), adjust = 1),
               trControl = trControl)

model

train.preds <- predict(model, train)
test.preds <- predict(model, test)
postResample(train.preds, train$label)
postResample(test.preds, test$label)

confusionMatrix(train.preds, train$label)
confusionMatrix(test.preds, test$label)

library(e1071)
# with e1071 package
model <- naiveBayes(label ~ .,
                    data = train,
                    laplace = 1)

# this takes a very long time to predict...
start <- as.numeric(as.POSIXct(Sys.time()))
train.preds <- predict(model, train)
end <- as.numeric(as.POSIXct(Sys.time()))
print(paste(c('took', end-start, 'seconds'), sep = ' '))
test.preds <- predict(model, test)

postResample(train.preds, train$label)
postResample(test.preds, test$label)

confusionMatrix(test.preds, test$label)
# don't know why the accuracy is so low on train/test
